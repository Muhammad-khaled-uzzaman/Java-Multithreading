package DynamicMethodDispatch_2;

public class DynamicMehtodDispatchAbstractClass {

    public static void main(String[] args) {
        CseStudent s1 = new CseStudent("Rahim", 266.5);
        ArchStudent s2 = new ArchStudent("Karim", 255.5);
        System.out.println(Student.compareStudent(s1, s2));

        System.out.println("Rahim Cgpa : " + s1.calculateCgpa());
        System.out.println("Karim Cgpa : " + s2.calculateCgpa());
    }
}
