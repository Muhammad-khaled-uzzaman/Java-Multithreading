
package boolean_test;

public class Test5 {
    
    public static void main(String[] args) {
        // creating different Boolean objects 
        Boolean b1 = new Boolean("True"); 
        Boolean b2 = new Boolean("False"); 
        Boolean b3 = new Boolean("GeeksForGeeks"); 
        Boolean b4 = new Boolean(null); 
      
          
        // getting String value of Boolean objects 
        String str1 = b1.toString(); 
        String str2 = b2.toString(); 
        String str3 = b3.toString(); 
        String str4 = b4.toString(); 
          
        System.out.println(str1); 
        System.out.println(str2); 
        System.out.println(str3); 
        System.out.println(str4); 
    }
}
