
package Example_4;

public class ThreadNaming extends Thread {
    
    @Override
    public void run(){
        System.out.println("Thread is running......");
    }
}
