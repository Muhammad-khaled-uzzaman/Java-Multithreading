package Example_5;

public class Main {

    public static void main(String[] args) {
        // creating two threads 
        ThreadNaming t1 = new ThreadNaming();
        ThreadNaming t2 = new ThreadNaming();

        t1.start();
        t2.start();
    }
}
