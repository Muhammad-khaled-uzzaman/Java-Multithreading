
package character_test;

public class Test4 {
    public static void main(String[] args) {
        System.out.println(Character.isLowerCase('A'));  
    System.out.println(Character.isLowerCase('a'));  
    System.out.println(Character.isLowerCase(97));  
    }
}
