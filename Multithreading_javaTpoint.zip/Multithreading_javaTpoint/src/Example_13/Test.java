
package Example_13;

public class Test extends Thread {
    
    @Override
    public void run(){
        System.out.println("Name : "+Thread.currentThread().getName());
        System.out.println("Daemon : "+Thread.currentThread().isDaemon());
    }
    public static void main(String[] args) {
        Test t1 = new Test();
        Test t2 = new Test();
        
        t1.start();
        t1.setDaemon(true);
       
        t2.start();
    }
}
