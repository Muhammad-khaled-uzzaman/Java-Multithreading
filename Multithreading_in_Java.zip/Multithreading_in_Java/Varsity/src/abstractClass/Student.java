package abstractClass;

public abstract class Student {

    String name;
    double totalCPGA;

    public Student(String name, double totalCPGA) {
        super();
        this.name = name;
        this.totalCPGA = totalCPGA;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getTotalCPGA() {
        return totalCPGA;
    }

    public void setTotalCPGA(double totalCPGA) {
        this.totalCPGA = totalCPGA;
    }

    abstract double calculateCgpa();

    public static String compareStudent(Student s1, Student s2) {
        String name = "";
        if (s1.calculateCgpa() < s2.calculateCgpa()) {
            name = s2.getName();
        } else {
            name = s1.getName();
        }
        return name;
    }
}
