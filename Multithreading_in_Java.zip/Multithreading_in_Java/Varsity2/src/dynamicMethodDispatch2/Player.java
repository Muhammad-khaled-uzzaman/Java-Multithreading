package dynamicMethodDispatch2;

public abstract class Player implements Charecter {

    String name;

    public Player(String name) {
        super();
        this.name = name;
    }

    String getName() {
        return name;
    }
    
    @Override
    public String doMove(){
        return "Player";
    }
    
    @Override
    public String doJump(){
        return "Player";
    }
}
