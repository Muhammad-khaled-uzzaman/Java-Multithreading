package Example_5;

public class Test {

    public static void main(String[] args) {
        try {
            System.out.println("Entering into Deadlock");
            Thread.currentThread().join();
            System.out.println("This statement will never execute");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}
