package Example_8;

public class Main {

    public static void main(String[] args) {

        Sender S1 = new Sender(" Hi ");
        Sender S2 = new Sender(" Bye ");
        // Start two threads of ThreadedSend type 
        S1.start();
        S2.start();

        // wait for threads to end 
        try {
            S1.join();
            S2.join();
        } catch (Exception e) {
            System.out.println("Interrupted");
        }
    }
}
