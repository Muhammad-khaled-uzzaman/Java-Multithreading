package Example_1;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        try {
            int n = Integer.parseInt(input.nextLine());

            if (99 % n == 0) {
                System.out.println(n + " is a factor of 99");
            }
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic : " + e);
        } catch (NumberFormatException e) {
            System.out.println("Number Format Exception : " + e);
        }
    }
}
