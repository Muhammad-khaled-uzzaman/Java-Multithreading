
package Example_15;

public class ThreadNaming extends Thread {
    
    public ThreadNaming(String name){
        super(name);
    }
    
    @Override
    public void run(){
        System.out.println("Thread is running.....");
    }
}
