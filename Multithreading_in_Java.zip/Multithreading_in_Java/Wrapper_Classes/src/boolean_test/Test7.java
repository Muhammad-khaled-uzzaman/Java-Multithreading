package boolean_test;

public class Test7 {

    public static void main(String[] args) {
        // creating different Boolean objects 
        Boolean b1 = new Boolean("True");
        Boolean b2 = new Boolean("False");
        Boolean b3 = new Boolean("TrUe");
        Boolean b4 = new Boolean(null);

        // checking equality of Boolean objects 
        System.out.println(b1.equals(b2));
        System.out.println(b2.equals(b4));
        System.out.println(b1.equals(b3));
        System.out.println(b1.equals(b4));
    }
}
