
package boolean_test;

public class Test3 {
    
    public static void main(String[] args) {
        // creating boolean variable using different Strings 
        Boolean b1 = Boolean.valueOf("true"); 
        Boolean b2 = Boolean.valueOf("TRue"); 
        Boolean b3 = Boolean.valueOf("False"); 
        Boolean b4 = Boolean.valueOf("GeeksForGeeks"); 
        Boolean b5 = Boolean.valueOf(null); 
          
        System.out.println(b1); 
        System.out.println(b2); 
        System.out.println(b3); 
        System.out.println(b4); 
        System.out.println(b5); 
    }
}
