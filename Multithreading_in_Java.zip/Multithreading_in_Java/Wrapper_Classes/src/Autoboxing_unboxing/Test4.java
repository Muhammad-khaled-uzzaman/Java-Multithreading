
package Autoboxing_unboxing;

import java.util.ArrayList;
import java.util.List;

public class Test4 {
    
    public static void main(String[] args) {
        
        ArrayList<Integer>list = new ArrayList<Integer>();
        
        for (int i = 0; i < 10; i++) {
            list.add(i);
        }
        
        int sumOdd =  sumOfOddNumber(list);
        System.out.println(sumOdd);
    }
    
    public static int  sumOfOddNumber(List<Integer>list){
        
        int sum = 0;
        // unboxing of i automatically 
        for(Integer i : list){
            if(i%2 !=0){
                sum +=i;
            }
        }
        return sum;
    }
}
