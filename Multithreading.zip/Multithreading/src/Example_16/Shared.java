package Example_16;

public class Shared {
    
    static int count = 0;
}
