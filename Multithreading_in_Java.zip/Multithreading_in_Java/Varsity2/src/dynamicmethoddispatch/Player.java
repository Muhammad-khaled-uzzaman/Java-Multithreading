
package dynamicmethoddispatch;

public abstract class Player implements Charecter  {
    
    String name;
  Player(String name){
        //super();
        this.name = name;
    }
    
    String getName(){
        return name;
    }
    
    public String doMove(){
        return "";
    }
    public String doJump(){
        return "";
    }
    
}
