
package Example_1;

public class Test {
    
    public static void main(String[] args) {
        
        Runtime run = Runtime.getRuntime();
        System.out.println(""+run.freeMemory());
    }
}
