package Example_10;

public class Main {

    public static void main(String[] args) {
        Multithread t = new Multithread();
        t.increment();
        System.out.println(t.getValue());
    }
}
