package boolean_test;

public class Test9 {

    public static void main(String[] args) {

        boolean b1 = true;
        boolean b2 = false;
        boolean b3 = true;
        boolean b4 = false;

        //comparing b1,b2,b3,b4 
        System.out.println(Boolean.compare(b1, b2));
        System.out.println(Boolean.compare(b1, b3));
        System.out.println(Boolean.compare(b2, b1));
        System.out.println(Boolean.compare(b2, b4));

        // The following statement throws NullPointerExcetion 
        //  System.out.println(Boolean.compare(b1, null)); 
    }
}
