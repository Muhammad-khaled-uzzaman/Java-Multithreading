package interfa;

public abstract class Mobile {

    String model;

    Mobile(String model) {
        this.model = model;
    }

    abstract void sendingMessage(String message, Mobile m);

    abstract void receivingMessage(String message);

}
