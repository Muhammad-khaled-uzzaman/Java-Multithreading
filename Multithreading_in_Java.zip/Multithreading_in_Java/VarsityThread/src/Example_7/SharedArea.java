
package Example_7;

public class SharedArea {
    String str = "";
     void putSharedArea(String s){
        
        str = str +"["+s;
        
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            System.out.println("Interrupted");
        }
        str = str+"]";
    }
    
    void show(){
        System.out.println(str);
    }
}
