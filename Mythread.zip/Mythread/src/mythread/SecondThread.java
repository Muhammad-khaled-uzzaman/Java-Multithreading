/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mythread;

/**
 *
 * @author pc
 */
public class SecondThread implements Runnable {

    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println("Messag from Second Thread : " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException interruptedException) {
                System.out.println("Second Thread is interrupted when it is sleeping"
                        + interruptedException);
            }
        }

    }

}
