package dynamicMethodDispatch2;

public class InterfaceAndDynamicMethodDispatchDemo {

    public static void main(String[] args) {
        Player cat = new PlayerCat("cat");
        Player dog = new PlayerDog("dog");
        Player tiger = new PlayerTiger("tiger");

        cat.doAttack(dog);
        dog.doAttack(tiger);
    }
}
