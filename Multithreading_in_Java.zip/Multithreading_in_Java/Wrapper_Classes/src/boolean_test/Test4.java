
package boolean_test;

public class Test4 {
    
    public static void main(String[] args) {
        
        // creating boolean variable 
        boolean b1 = true; 
        boolean b2 = false; 
          
        // getting String value of the primitives boolean 
        String str1 = Boolean.toString(b1); 
        String str2 = Boolean.toString(b2); 
          
        System.out.println(str1); 
        System.out.println(str2); 
    }
}
