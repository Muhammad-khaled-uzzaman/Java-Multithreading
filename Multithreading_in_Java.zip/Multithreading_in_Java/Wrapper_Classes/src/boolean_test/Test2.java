
package boolean_test;

public class Test2 {
    
    public static void main(String[] args) {
         // creating boolean variable 
        boolean b1 = true; 
        boolean b2 = false; 
          
        // getting Boolean objects from boolean variables 
        Boolean b3 = Boolean.valueOf(b1); 
        Boolean b4 = Boolean.valueOf(b2); 
          
        System.out.println(b3); 
        System.out.println(b4); 
          
    }
}
