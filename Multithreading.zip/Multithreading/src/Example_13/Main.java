package Example_13;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        Geek gk = new Geek();
        List<String> list = new ArrayList<String>();
        gk.geekName("mohit", list);
        System.out.println(gk.name);
        System.out.println(gk.count);
    }
}
