
package Example_4;

public class ChildeThread extends Thread {
    
    @Override
    public void run(){
        for (int i = 0; i < 5; i++) {
            System.out.println("Child thread");
        }
    }
}
