package problem_2;

import java.util.Random;

public class WifeThread implements Runnable {

    SharedAccount sc;

    WifeThread(SharedAccount sc) {
        this.sc = sc;
    }

    void dipositor() {
        Random rm = new Random();
        sc.deposit(rm.nextInt(500), "Wife");

    }

    void WithDrawer() {
        Random rm = new Random();
        sc.withdraw(rm.nextInt(500), "Wife");

    }

    @Override
    public void run() {
        for (int i = 0; i < 2; i++) {
            dipositor();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            WithDrawer();
        }
    }
}
