package Example_6;

public class Test2 extends Thread {

    @Override
    public void run() {
        for (int i = 1; i < 5; i++) {
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        Test2 t1 = new Test2();
        Test2 t2 = new Test2();
        t1.run();
        t2.run();

    }
}
