/*
Thread creation by implementing the Runnable Interface
*/
package Example2;

public class MultithreadingDemo implements Runnable {

    @Override
    public void run(){
        try{
            System.out.println("Thread "+Thread.currentThread().getId()+" is running");
        }catch(Exception e){
            System.out.println("Exception is caught");
        }
    }
    
}
