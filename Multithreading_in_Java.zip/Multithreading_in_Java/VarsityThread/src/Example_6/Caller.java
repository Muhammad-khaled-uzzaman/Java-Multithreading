package Example_6;

public class Caller implements Runnable {
    
    String msg;
    
    SharedArea targ;
    
    Thread t;
    
    public Caller(SharedArea targ, String s) {
        msg = s;
        this.targ = targ;
        
        t = new Thread(this);
        
        t.start();
        
    }
    
    @Override
    public void run() {
        targ.putSharedArea(msg);
    }
    
}
