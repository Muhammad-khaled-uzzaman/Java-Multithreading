
package InnerClass;

public class Student {
    class Roll{
		int year,session, deptCode, serial;

		public Roll(int year, int session, int deptCode, int serial) {
			super();
			this.year = year;
			this.session = session;
			this.deptCode = deptCode;
			this.serial = serial;
			if(serial>0 && serial <=50){
				assignedSection="A";
			}else if(serial > 50 && serial <=100)
			{
				assignedSection="B";
			}else{
				assignedSection="C";
			}
				
		}

		public int getYear() {
			return year;
		}

		public void setYear(int year) {
			this.year = year;
		}

		public int getSession() {
			return session;
		}

		public void setSession(int session) {
			this.session = session;
		}

		public int getDeptCode() {
			return deptCode;
		}

		public void setDeptCode(int deptCode) {
			this.deptCode = deptCode;
		}

		public int getSerial() {
			return serial;
		}

		public void setSerial(int serial) {
			this.serial = serial;
		}
		
                @Override
		public String toString(){
			return year+".0"+session+".0"+deptCode+"."+serial;
		}
	}
	
	Roll roll;
	String name;
	String assignedSection;
	public Student(int year, int session, int deptCode, int serial, String name) {
		this.roll = new Roll(year, session, deptCode, serial);
		this.name = name;
	}
	
	
    @Override
	public String toString(){
		return "Name: " + this.name+" roll: "+roll+" section: "+assignedSection;
				
	}
	
	
}

