
package dynamicmethoddispatch;

public interface Charecter {
    
    String doMove();
    String doJump();
    void doAttack(Player a);
    
}
