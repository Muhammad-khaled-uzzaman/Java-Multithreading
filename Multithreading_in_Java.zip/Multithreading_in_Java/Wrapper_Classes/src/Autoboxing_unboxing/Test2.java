
package Autoboxing_unboxing;

import java.util.ArrayList;

public class Test2 {
    
    public static void main(String[] args) {
        
        ArrayList<Integer>list = new ArrayList<Integer>();
         /* Here we are creating a list 
          of elements of Integer type. 
          adding the int primitives type values */
        for (int i = 0; i < 10; i++) {
            list.add(i);
        }
    }
}
