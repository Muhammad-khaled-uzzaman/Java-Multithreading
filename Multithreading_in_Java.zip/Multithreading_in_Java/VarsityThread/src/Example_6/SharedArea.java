
package Example_6;

public class SharedArea {
    
    String str = "";
    synchronized void putSharedArea(String s){
        
        str = str +"["+s;
        
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            System.out.println("Interrupted");
        }
        str = str+"]";
    }
    
    void show(){
        System.out.println(str);
    }
}
