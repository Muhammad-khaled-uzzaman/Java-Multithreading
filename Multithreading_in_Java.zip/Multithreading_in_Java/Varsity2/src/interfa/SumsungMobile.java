
package interfa;

public class SumsungMobile extends Mobile implements SensonInterfaceForMobile {
    
    public SumsungMobile(String model) {
		super(model);
	}
	
    @Override
	public int getGPSPosition() {
		return (int)(Math.random()*100);
	}
	
    @Override
	public int getVelocity() {
		return (int)(Math.random()*50);
	}
	
    @Override
	public void sendGPSPosition(SensonInterfaceForMobile s) {
		int currentGPSPositon = getGPSPosition();
		System.out.println("sending postion from Sumsung: "+currentGPSPositon);
		s.receiveGPSPosition(currentGPSPositon);
		
	}
	
    @Override
	public void receiveGPSPosition(int position) {
		System.out.println("receiving GPS position to sumsung: "+position);
	}

    @Override
	void sendingMessage(String message, Mobile m) {
		System.out.println("seding meassge from Sumsung: "+message);
		m.receivingMessage(message);
	}
	
    @Override
	void receivingMessage(String message) {
		System.out.println("Receiving message to Sumsung: "+message);
	}
}


