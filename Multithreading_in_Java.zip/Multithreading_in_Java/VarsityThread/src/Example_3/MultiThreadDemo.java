
package Example_3;

public class MultiThreadDemo {
    
    public static void main(String[] args) {
        new NewThread("One");
        new NewThread("Two");
        new NewThread("Three");
        
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            System.out.println("Main Thread Interruoted");
        }
        System.out.println("Main Thread Exiting");
    }
}
