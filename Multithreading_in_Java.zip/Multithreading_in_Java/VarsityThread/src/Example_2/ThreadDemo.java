package Example_2;

public class ThreadDemo {

    public static void main(String[] args) {
        new NT();

        try {
            for (int i = 5; i > 0; i--) {
                System.out.println("Main Thread : " + i);

                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted main thread");
        }
        System.out.println("Main thread exiting");
    }
}
