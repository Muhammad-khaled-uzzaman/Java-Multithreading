package Example_5;

public class HiLoPri {

    public static void main(String[] args) {
        Clicker hi = new Clicker(Thread.NORM_PRIORITY + 2);
        Clicker lo = new Clicker(Thread.NORM_PRIORITY - 2);

        lo.start();
        hi.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Main thraed Interrupteed");
        }

        lo.stop();
        hi.stop();

        try {
            hi.t.join();
            lo.t.join();
        } catch (InterruptedException e) {
            System.out.println("InterruptedException caught");
        }

        System.out.println("Low-priority thread : " + lo.click);
        System.out.println("High-priority thread : " + hi.click);
    }
}
