
package DynamicMethodDispatch_2;

public class ArchStudent extends Student {
    
    ArchStudent(String name,double totalCgpa){
        super(name,totalCgpa);
    }
    
    @Override
    double calculateCgpa(){
        return super.getTotalCgpa()/152.5;
    }
}
