package character_test;

public class Test5 {

    public static void main(String[] args) {
        System.out.println(Character.toUpperCase('a'));
        System.out.println(Character.toUpperCase(97));
        System.out.println(Character.toUpperCase(48));
    }
}
