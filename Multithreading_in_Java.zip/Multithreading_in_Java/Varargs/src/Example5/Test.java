package Example5;

/*
Compile time error as there are two varargs
*/
public class Test {

    /* public static void fun(String ...str,int ...q) */
    {

        // Compile time error as there are two
        // varargs
        
        System.out.println("Number of arguments ");
    }
    public static void main(String[] args) {
        
    }
}
