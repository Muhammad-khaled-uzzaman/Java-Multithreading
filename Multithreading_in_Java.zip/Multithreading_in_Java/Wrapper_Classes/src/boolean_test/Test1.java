
package boolean_test;

public class Test1 {
    
    public static void main(String[] args) {
        
        Boolean b1 = new Boolean("true");
        Boolean b2 = new Boolean("false");
        Boolean b3 = new Boolean("Geeks");
        
         
        // getting primitive boolean value 
        boolean b4 = b1.booleanValue(); 
        boolean b5 = b2.booleanValue(); 
        boolean b6 = b3.booleanValue(); 
          
        System.out.println(b4); 
        System.out.println(b5); 
        System.out.println(b6); 
    }
}
