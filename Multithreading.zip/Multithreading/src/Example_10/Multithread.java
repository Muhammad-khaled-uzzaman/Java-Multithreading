
package Example_10;

public class Multithread {
    
    private int i = 0;
    
    public void increment(){
        i++;
    }
    
    public int getValue(){
        return i;
    }
}
