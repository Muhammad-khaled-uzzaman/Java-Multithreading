package varsityexception;

import java.util.Scanner;

public class StudentFormDemo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String email = sc.nextLine();

        try {
            if (email.endsWith("@gmail.com")) {

                throw new GmailException(email);
            }
        } catch (GmailException e) {
            System.out.println(e);
        }
    }
}
