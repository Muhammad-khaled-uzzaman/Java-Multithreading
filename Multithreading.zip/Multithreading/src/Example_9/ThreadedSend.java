package Example_9;

public class ThreadedSend extends Thread {

    private String msg;
    private Thread t;
    Sender sender;

    // Recieves a message object and a string 
    // message to be sent 
    ThreadedSend(String m, Sender obj) {
        msg = m;
        sender = obj;
    }

    @Override
    public void run() {
        // Only one thread can send a message 
        // at a time. 
       
            // synchronizing the snd object 
            sender.send(msg);
        
    }
}
