
package Example_2;

public class Test extends Thread {
    
    @Override
    public void run(){
        System.out.println("Thread is running");
    }
    
    public static void main(String[] args) {
        Test t =  new Test();
        t.start();
    }
}
