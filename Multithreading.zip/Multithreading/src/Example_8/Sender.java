package Example_8;

public class Sender extends Thread {

    private String msg;
    private Thread t;
    Sender sender;

    public Sender(String msg) {
        this.msg = msg;
    }

    public synchronized  void send(String msg) {
        System.out.println("Sending\t" + msg);
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Thread  interrupted.");
        }
        System.out.println("\n" + msg + "Sent");
    }

    @Override
    public void run() {
        send(msg);

    }
}
