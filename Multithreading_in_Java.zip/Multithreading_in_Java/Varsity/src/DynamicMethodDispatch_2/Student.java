package DynamicMethodDispatch_2;

public class Student {

    String name;
    double totalCgpa;

    public Student(String name, double totalCgpa) {
        this.name = name;
        this.totalCgpa = totalCgpa;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getTotalCgpa() {
        return totalCgpa;
    }

    public void setTotalCgpa(double totalCgpa) {
        this.totalCgpa = totalCgpa;
    }

    double calculateCgpa() {
        System.out.println("do nothing...");
        return 0.0;
    }

    public static String compareStudent(Student s1, Student s2) {
        String name = "";
        if (s1.getTotalCgpa() > s2.getTotalCgpa()) {
            name = s1.getName();
        } else {
            name = s2.getName();
        }
        return name;
    }

}
