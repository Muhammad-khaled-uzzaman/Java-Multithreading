
package Example_6;

public class Test1 extends Thread {
    
    @Override
    public void run(){
        System.out.println("running....");
    }
    
    public static void main(String[] args) {
        Test1 t1 = new Test1();
        t1.run();
    }
}
