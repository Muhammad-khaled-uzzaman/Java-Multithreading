package Problem;

public class SharedAccount {

    int balance;

    SharedAccount() {
        balance = 0;
    }

    synchronized void deposit(int amount, String who) {
        this.balance += amount;

        System.out.println(who + " is Deposited " + amount + " current balance is " + this.balance);

        if (balance > 0) {
            notify();
        }
    }

    synchronized void withdraw(int amount, String who) {
        while ((this.balance - amount) < 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        this.balance -= amount;
        System.out.println(who + " is withdrawing " + amount + " current balance is " + this.balance);

    }
}
