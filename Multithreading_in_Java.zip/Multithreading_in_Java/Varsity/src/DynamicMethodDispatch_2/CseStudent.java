
package DynamicMethodDispatch_2;

public class CseStudent extends Student {
    
    CseStudent(String name,double totalCgpa){
        super(name,totalCgpa);
    }
    
    @Override
    double calculateCgpa(){
        return super.getTotalCgpa()/141.5;
    }
}
