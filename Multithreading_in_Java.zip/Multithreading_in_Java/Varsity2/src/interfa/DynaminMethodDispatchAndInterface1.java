package interfa;

public class DynaminMethodDispatchAndInterface1 {

    public static void main(String[] args) {
        IPhone iphone5s = new IPhone("IPhone5s");
        SumsungMobile A30 = new SumsungMobile("A30");
        WaltonMobile ZX3 = new WaltonMobile("ZX3");

        iphone5s.sendingMessage("Hello", ZX3);

        //A30.sendGPSPosition(ZX3);
        A30.sendGPSPosition(iphone5s);
    }
}
