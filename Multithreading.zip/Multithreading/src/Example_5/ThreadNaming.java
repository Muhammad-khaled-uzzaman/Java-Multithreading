package Example_5;

public class ThreadNaming extends Thread {

    @Override
    public void run() {
        // getting the current thread 's name. 
        System.out.println("Fetching current thread name..");
        System.out.println(Thread.currentThread().getName());
    }
}
